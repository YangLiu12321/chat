
exports.config = {
    db_name: 'ubuy',
    db_user: 'root',
    db_pwd: '123456',
    tb_account: 'account',
    tb_account_params: ['sid', 'name', 'password', 'gender', 'state', 'code'],
    tb_account_data: {sid: undefined, name: undefined, pwd: undefined,
                        gender: undefined, state: undefined, code: undefined},
    user_native_pwd: '123456',
    mail_server:'gmail',
    mail_account: 'limlim.koh.ll@gmail.com',
    mail_pwd:'aaa1999!',
    server_port: '8081',
    server_address: 'http://localhost:'
}
